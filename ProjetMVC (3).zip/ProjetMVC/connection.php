<?php
// connection.php
$host = "localhost";
$username = "root"; // Change if needed
$password = ""; // Change if needed
$dbname = "project";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}
?>