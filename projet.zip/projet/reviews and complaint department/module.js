document.addEventListener("DOMContentLoaded", function() {
  const complaintform = document.getElementById("complaintform");
  const ratingform = document.getElementById("ratingform");
  const radios = document.querySelectorAll('input[name="feedback"]');

  radios.forEach(radio => {
    radio.addEventListener("change", () => {
      // Hide both forms
      complaintform.classList.add("hidden");
      ratingform.classList.add("hidden");

      // Show the selected one
      if (radio.value === "cp") {
        complaintform.classList.remove("hidden");
      } else if (radio.value === "rt") {
        ratingform.classList.remove("hidden");
      }
    });
  });
});
const curseur = document.getElementById('rating');
const valeur = document.getElementById('valeur');
curseur.addEventListener('input', function() {
  valeur.textContent = curseur.value;
});