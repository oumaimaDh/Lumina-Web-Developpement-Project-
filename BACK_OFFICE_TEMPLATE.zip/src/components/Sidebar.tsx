import { motion } from 'motion/react';
import { Calendar, Globe, Users, BarChart3, Settings, Home, Sparkles, CheckSquare } from 'lucide-react';
import { StarIcon } from './StarIcon';

interface SidebarProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

const menuItems = [
  { id: 'dashboard', label: 'Dashboard', icon: Home },
  { id: 'events', label: 'Events', icon: Calendar },
  { id: 'participants', label: 'Participants', icon: Users },
  { id: 'sponsors', label: 'Sponsors', icon: Globe },
  { id: 'tasks', label: 'Admin Tasks', icon: CheckSquare },
  { id: 'analytics', label: 'Analytics', icon: BarChart3 },
  { id: 'settings', label: 'Settings', icon: Settings }
];

export function Sidebar({ activeTab, onTabChange }: SidebarProps) {
  return (
    <motion.div
      className="w-64 bg-white rounded-2xl p-6 shadow-xl border border-gray-200 relative overflow-hidden"
      initial={{ x: -100, opacity: 0 }}
      animate={{ x: 0, opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      {/* Decorative background */}
      <div className="absolute top-0 right-0 w-32 h-32 bg-blue-50 rounded-full -translate-y-1/2 translate-x-1/2 blur-3xl opacity-50" />
      <div className="absolute bottom-0 left-0 w-24 h-24 bg-indigo-50 rounded-full translate-y-1/2 -translate-x-1/2 blur-3xl opacity-50" />

      {/* Navigation */}
      <nav className="space-y-2 relative z-10 mt-6">
        {menuItems.map((item, index) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          
          return (
            <motion.div
              key={item.id}
              className="relative"
              initial={{ x: -50, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ delay: index * 0.1 }}
            >
              {/* Particle effect on active item */}
              {isActive && (
                <>
                  {[...Array(5)].map((_, i) => (
                    <motion.div
                      key={i}
                      className="absolute w-1 h-1 bg-[#F4EDE4] rounded-full"
                      style={{
                        left: '50%',
                        top: '50%',
                      }}
                      initial={{ 
                        x: 0, 
                        y: 0,
                        scale: 1,
                        opacity: 1 
                      }}
                      animate={{
                        x: [0, (Math.random() - 0.5) * 100],
                        y: [0, (Math.random() - 0.5) * 100],
                        scale: [1, 0],
                        opacity: [1, 0],
                      }}
                      transition={{
                        duration: 1.5,
                        repeat: Infinity,
                        delay: i * 0.2,
                        ease: "easeOut"
                      }}
                    />
                  ))}
                </>
              )}

              <motion.button
                onClick={() => onTabChange(item.id)}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-2xl transition-all relative overflow-hidden ${
                  isActive
                    ? 'bg-gradient-to-r from-[#243B53] to-[#4E5F7C] text-[#F4EDE4] shadow-xl'
                    : 'text-[#243B53] hover:bg-[#6B85A8]/20'
                }`}
                whileHover={{ 
                  x: isActive ? 0 : 8,
                  scale: isActive ? 1 : 1.02
                }}
                whileTap={{ scale: 0.95 }}
              >
                {/* Animated gradient overlay for active state */}
                {isActive && (
                  <motion.div
                    className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent"
                    animate={{
                      x: ['-100%', '200%'],
                    }}
                    transition={{
                      duration: 2,
                      repeat: Infinity,
                      ease: "linear"
                    }}
                  />
                )}

                {/* Icon with rotation animation */}
                <motion.div
                  animate={isActive ? {
                    rotate: [0, 360],
                    scale: [1, 1.2, 1],
                  } : {}}
                  transition={{
                    duration: 0.6,
                    ease: "easeInOut"
                  }}
                >
                  <Icon className="h-5 w-5 relative z-10" />
                </motion.div>

                <span className="relative z-10">{item.label}</span>

                {/* Active indicator with morphing star */}
                {isActive && (
                  <motion.div
                    className="ml-auto relative z-10"
                    initial={{ scale: 0, rotate: -180 }}
                    animate={{ 
                      scale: 1, 
                      rotate: 0,
                    }}
                    transition={{ 
                      type: "spring", 
                      stiffness: 200,
                      damping: 10
                    }}
                  >
                    <motion.div
                      animate={{
                        rotate: [0, 360],
                      }}
                      transition={{
                        duration: 3,
                        repeat: Infinity,
                        ease: "linear"
                      }}
                    >
                      <StarIcon animate={false} className="w-5 h-5" />
                    </motion.div>
                  </motion.div>
                )}

                {/* Hover trail effect */}
                {!isActive && (
                  <motion.div
                    className="absolute left-0 top-0 h-full w-1 bg-gradient-to-b from-[#6B85A8] to-[#243B53] rounded-r-full"
                    initial={{ scaleY: 0 }}
                    whileHover={{ scaleY: 1 }}
                    transition={{ duration: 0.2 }}
                  />
                )}
              </motion.button>
            </motion.div>
          );
        })}
      </nav>

      {/* Help Section */}
      <motion.div
        className="mt-8 p-5 bg-gradient-to-br from-[#6B85A8]/20 to-[#243B53]/10 rounded-2xl border-2 border-[#6B85A8]/30 relative overflow-hidden"
        initial={{ y: 50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.6 }}
      >
        {/* Animated background glow */}
        <motion.div
          className="absolute inset-0 bg-gradient-to-br from-[#6B85A8]/10 to-transparent"
          animate={{
            opacity: [0.3, 0.6, 0.3],
          }}
          transition={{
            duration: 2,
            repeat: Infinity,
          }}
        />

        <div className="flex justify-center mb-3 relative z-10">
          <motion.div
            className="relative"
            animate={{ 
              rotate: [0, 10, -10, 0],
              y: [0, -5, 0]
            }}
            transition={{ 
              duration: 2, 
              repeat: Infinity,
              ease: "easeInOut"
            }}
          >
            <StarIcon className="w-10 h-10 text-[#243B53]" />
            {/* Pulsing rings around star */}
            <motion.div
              className="absolute inset-0 rounded-full border-2 border-[#6B85A8]"
              animate={{
                scale: [1, 1.8],
                opacity: [0.8, 0],
              }}
              transition={{
                duration: 1.5,
                repeat: Infinity,
              }}
            />
            <motion.div
              className="absolute inset-0 rounded-full border-2 border-[#6B85A8]"
              animate={{
                scale: [1, 1.8],
                opacity: [0.8, 0],
              }}
              transition={{
                duration: 1.5,
                repeat: Infinity,
                delay: 0.5,
              }}
            />
          </motion.div>
        </div>
        <h4 className="text-[#243B53] text-center mb-2 relative z-10">Need Help?</h4>
        <p className="text-[#4E5F7C] text-sm text-center relative z-10">
          Check our documentation or contact support
        </p>

        {/* Floating mini stars */}
        {[...Array(3)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute text-[#6B85A8]/30"
            style={{
              left: `${20 + i * 30}%`,
              top: `${10 + i * 20}%`,
            }}
            animate={{
              y: [0, -10, 0],
              opacity: [0.3, 0.6, 0.3],
              rotate: [0, 180, 360],
            }}
            transition={{
              duration: 2 + i * 0.5,
              repeat: Infinity,
              delay: i * 0.3,
            }}
          >
            <StarIcon className="w-3 h-3" />
          </motion.div>
        ))}
      </motion.div>

      {/* Bottom decorative element */}
      <motion.div
        className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-[#6B85A8] via-[#243B53] to-[#6B85A8]"
        animate={{
          backgroundPosition: ['0% 50%', '100% 50%', '0% 50%'],
        }}
        transition={{
          duration: 3,
          repeat: Infinity,
          ease: "linear"
        }}
      />
    </motion.div>
  );
}