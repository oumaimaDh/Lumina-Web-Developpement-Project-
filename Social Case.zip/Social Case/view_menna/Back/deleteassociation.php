<?php
require_once __DIR__ . '/../../controller_menna/socialcasecontroller.php';

if (isset($_GET['id'])) {
    $id_association = $_GET['id'];

    $socialCaseController = new SocialCaseController();
    $socialCaseController->deleteAssociation($id_association);

    header('Location: listassociations.php');
    exit();
} else {
    echo "Association ID not provided.";
}
?>