<!DOCTYPE html>
<?php
require_once __DIR__ . '/../../controller_menna/socialcasecontroller.php';
require_once __DIR__ . '/../../Model_menna/socialcasemodel.php';

$socialCaseController = new SocialCaseController();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_association'])) {
    $name = $_POST['name'];
    $phone = $_POST['phone'];
    $location = $_POST['location'];
    $email = $_POST['email'];
    $availabelity = isset($_POST['availabelity']) ? (int)$_POST['availabelity'] : 0;
    $id_category = $_POST['id_category'];

    $association = new Association(null, $name, $phone, $location, $email, $availabelity, $id_category);
    $socialCaseController->addAssociation($association);

    // Redirect to prevent form resubmission
    header('Location: associations.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lumina - Dashboard</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .dashboard-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            text-align: center;
        }
        
        .stat-number {
            font-size: 2.5em;
            font-weight: bold;
            color: #4a5568;
            margin-bottom: 10px;
        }
        
        .stat-label {
            color: #718096;
            font-size: 1.1em;
        }
        
        .recent-activities {
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .activity-item {
            padding: 15px 0;
            border-bottom: 1px solid #e2e8f0;
            display: flex;
            align-items: center;
        }
        
        .activity-item:last-child {
            border-bottom: none;
        }
        
        .activity-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: #edf2f7;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 15px;
        }
        
        .activity-content {
            flex: 1;
        }
        
        .activity-title {
            font-weight: bold;
            margin-bottom: 5px;
        }
        
        .activity-time {
            color: #718096;
            font-size: 0.9em;
        }

        /* Styles for Add Association Form */
        .add-association-section {
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }

        .add-association-section h2 {
            color: #333;
            margin-bottom: 20px;
            font-size: 1.8em;
            border-bottom: 2px solid #eee;
            padding-bottom: 10px;
        }

        .add-association-form .form-group {
            margin-bottom: 15px;
        }

        .add-association-form label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: #555;
        }

        .add-association-form input[type="text"],
        .add-association-form input[type="email"],
        .add-association-form select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 1em;
            box-sizing: border-box; /* Ensures padding doesn't increase width */
        }

        .add-association-form .btn-primary {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1em;
            transition: background-color 0.3s ease;
        }

        .add-association-form .btn-primary:hover {
            background-color: #45a049;
        }

        /* Styles for Associations List */
        .associations-list-section {
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }

        .associations-list-section h2 {
            color: #333;
            margin-bottom: 20px;
            font-size: 1.8em;
            border-bottom: 2px solid #eee;
            padding-bottom: 10px;
        }

        .associations-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        .associations-table th,
        .associations-table td {
            border: 1px solid #eee;
            padding: 12px 15px;
            text-align: left;
        }

        .associations-table th {
            background-color: #f8f8f8;
            font-weight: bold;
            color: #666;
        }

        .associations-table tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        .associations-table tr:hover {
            background-color: #f1f1f1;
        }

        .associations-table .btn-edit,
        .associations-table .btn-delete {
            display: inline-block;
            padding: 6px 12px;
            margin-right: 5px;
            border-radius: 4px;
            text-decoration: none;
            color: white;
            font-size: 0.9em;
        }

        .associations-table .btn-edit {
            background-color: #007bff;
        }

        .associations-table .btn-edit:hover {
            background-color: #0056b3;
        }

        .associations-table .btn-delete {
            background-color: #dc3545;
        }

        .associations-table .btn-delete:hover {
            background-color: #c82333;
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
        <aside class="sidebar">
            <div class="sidebar-header">
                <svg class="star-icon" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z"/>
                </svg>
                <span class="logo-text">Lumina</span>
            </div>

            <nav class="sidebar-nav">
                <a href="indexb.php" class="nav-item active" data-tab="dashboard">
                    <i class="fas fa-home"></i>
                    <span>Dashboard</span>
                </a>
                <a href="social_case.php" class="nav-item" data-tab="social">
                    <i class="fas fa-heart"></i>
                    <span>Social Cases</span>
                </a>
                <a href="listassociations.php" class="nav-item" data-tab="associations">
                    <i class="fas fa-users"></i>
                    <span>Associations</span>
                </a>
                <a href="#" class="nav-item" data-tab="jobs">
                    <i class="fas fa-briefcase"></i>
                    <span>Jobs</span>
                </a>
                <a href="#" class="nav-item" data-tab="forum">
                    <i class="fas fa-comments"></i>
                    <span>Forum</span>
                </a>
                <a href="#" class="nav-item" data-tab="settings">
                    <i class="fas fa-cog"></i>
                    <span>Settings</span>
                </a>
            </nav>

            <!-- Version Info -->
            <div class="version-info">
                <p>Version 23.0.0</p>
                <p class="version-date">2025</p>
            </div>
        </aside>

        <!-- Main Content -->
        <main class="main-content">
            <!-- Header with Logo -->
            <header class="dashboard-header">
                <!-- Logo -->
                <div class="header-logo">
                    <img src="logo.png.png" 
                         alt="Lumina Logo" 
                         class="logo-image">
                </div>

                <!-- Search Bar -->
                <div class="search-container">
                    <i class="fas fa-search search-icon"></i>
                    <input type="text" placeholder="Search jobs, associations..." class="search-input" id="globalSearch">
                </div>

                <!-- Date -->
                <div class="header-date">
                    <p id="currentDate"></p>
                </div>

                <!-- Actions -->
                <div class="header-actions">
                    <!-- Notifications -->
                    <button class="icon-btn" onclick="toggleNotifications()">
                        <i class="fas fa-bell"></i>
                        <span class="notification-dot" id="notificationDot"></span>
                    </button>

                    <!-- User Profile -->
                    <div class="user-profile" onclick="toggleUserMenu()">
                        <div class="user-info">
                            <p class="user-name">Stella Walton</p>
                            <p class="user-role">Administrator</p>
                        </div>
                        <div class="user-avatar">
                            <i class="fas fa-user"></i>
                        </div>
                    </div>
                </div>
            </header>

           
            <section class="add-association-section">
                <h2>Add New Association</h2>
                <form action="" method="POST" class="add-association-form">
                    <div class="form-group">
                        <label for="name">Name:</label>
                        <input type="text" id="name" name="name">
                    </div>
                    <div class="form-group">
                        <label for="phone">Phone:</label>
                        <input type="text" id="phone" name="phone">
                    </div>
                    <div class="form-group">
                        <label for="location">Location:</label>
                        <input type="text" id="location" name="location">
                    </div>
                    <div class="form-group">
                        <label for="email">Email:</label>
                        <input type="email" id="email" name="email">
                    </div>
                    <div class="form-group">
                        <label for="availabelity">Availabelity:</label>
                        <select id="availabelity" name="availabelity">
                            <option value="1">Available</option>
                            <option value="0">Not Available</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="id_category">Category:</label>
                        <select id="id_category" name="id_category">
                            <?php
                            $categories = $socialCaseController->getAllCategories();
                            foreach ($categories as $category) {
                                echo '<option value="' . htmlspecialchars($category['id_category']) . '">' . htmlspecialchars($category['name']) . '</option>';
                            }
                            ?>
                        </select>
                    </div>
                    <button type="submit" name="add_association" class="btn-primary">Add Association</button>
                    <a href="listassociations.php" class="btn-primary" style="margin-left: 10px; background-color: #007bff;">View Associations</a>
                </form>
            </section>


        </main>
    </div>

    <script src="scriptmenna.js"></script>
    <script>
        // Set current date
        document.getElementById('currentDate').textContent = new Date().toLocaleDateString('en-US', {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric'
        });
        
        function toggleNotifications() {
            alert('Notifications panel to be implemented');
        }
        
        function toggleUserMenu() {
            alert('User menu to be implemented');
        }

        // Update active nav item
        document.addEventListener('DOMContentLoaded', function() {
            const currentPage = window.location.pathname.split('/').pop();
            const navItems = document.querySelectorAll('.nav-item');
            
            navItems.forEach(item => {
                item.classList.remove('active');
                if (item.getAttribute('href') === currentPage) {
                    item.classList.add('active');
                }
            });
        });
    </script>
</body>
</html>