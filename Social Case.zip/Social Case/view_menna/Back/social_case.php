<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lumina</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .btn {
            padding: 8px 16px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            margin: 2px;
            font-size: 14px;
            transition: all 0.3s ease;
        }
        
        .btn-accept {
            background-color: #28a745;
            color: white;
        }
        
        .btn-accept:hover {
            background-color: #218838;
        }
        
        .btn-accept:disabled {
            background-color: #6c757d;
            cursor: not-allowed;
            opacity: 0.6;
        }
        
        .btn-reject {
            background-color: #dc3545;
            color: white;
        }
        
        .btn-reject:hover {
            background-color: #c82333;
        }
        
        .btn-reject:disabled {
            background-color: #6c757d;
            cursor: not-allowed;
            opacity: 0.6;
        }
        
        .status-pending {
            color: #ffc107;
            font-weight: bold;
        }
        
        .status-accepted {
            color: #28a745;
            font-weight: bold;
        }
        
        .status-rejected {
            color: #dc3545;
            font-weight: bold;
        }
        
        .action-buttons {
            display: flex;
            gap: 5px;
            flex-wrap: wrap;
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
        <aside class="sidebar">
            <div class="sidebar-header">
                <svg class="star-icon" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z"/>
                </svg>
                <span class="logo-text">Lumina</span>
            </div>

            <nav class="sidebar-nav">
                <a href="indexb.php" class="nav-item active" data-tab="dashboard">
                    <i class="fas fa-home"></i>
                    <span>Dashboard</span>
                </a>
                <a href="social_case.php" class="nav-item" data-tab="social">
                    <i class="fas fa-heart"></i>
                    <span>Social Cases </span>
                </a>
                <a href="#associations" class="nav-item" data-tab="associations">
                    <i class="fas fa-users"></i>
                    <span>Associations</span>
                </a>
                <a href="#jobs" class="nav-item" data-tab="jobs">
                    <i class="fas fa-briefcase"></i>
                    <span>Jobs</span>
                </a>
                <a href="#forum" class="nav-item" data-tab="forum">
                    <i class="fas fa-comments"></i>
                    <span>Forum</span>
                </a>
                <a href="#settings" class="nav-item" data-tab="settings">
                    <i class="fas fa-cog"></i>
                    <span>Settings</span>
                </a>
            </nav>

            <!-- Version Info -->
            <div class="version-info">
                <p>Version 23.0.0</p>
                <p class="version-date">2025</p>
            </div>
        </aside>

        <!-- Main Content -->
        <main class="main-content">
            <!-- Header with Logo -->
            <header class="dashboard-header">
                <!-- Logo -->
                <div class="header-logo">
                    <img src="logo.png.png" 
                         alt="Lumina Logo" 
                         class="logo-image">
                </div>

                <!-- Search Bar -->
                <div class="search-container">
                    <i class="fas fa-search search-icon"></i>
                    <input type="text" placeholder="Search jobs , associations.." class="search-input" id="globalSearch">
                </div>

                <!-- Date -->
                <div class="header-date">
                    <p id="currentDate"></p>
                </div>

                <!-- Actions -->
                <div class="header-actions">
                    <!-- Notifications -->
                    <button class="icon-btn" onclick="toggleNotifications()">
                        <i class="fas fa-bell"></i>
                        <span class="notification-dot" id="notificationDot"></span>
                    </button>

                    <!-- User Profile -->
                    <div class="user-profile" onclick="toggleUserMenu()">
                        <div class="user-info">
                            <p class="user-name">Stella Walton</p>
                            <p class="user-role">Administrator</p>
                        </div>
                        <div class="user-avatar">
                            <i class="fas fa-user"></i>
                        </div>
                    </div>
                </div>
            </header>

            <div id="social" class="tab-content active">
                <div class="table-container">
                    <table>
                        <thead>
                            <tr>
                                <th>ID Case</th>
                                <th>Category</th>
                                <th>Association</th>
                                <th>Submitted Date</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                  <?php
                  require_once __DIR__ . '/../../config.php';
                  require_once __DIR__ . '/../../controller_menna/socialcasecontroller.php';
                  require_once __DIR__ . '/../../Model_menna/socialcasemodel.php';

                  $socialCaseController = new SocialCaseController();
                  $socialCases = $socialCaseController->getAllSocialCases();

                  $categories_data = $socialCaseController->getAllCategories();
                  $categories_map = [];
                  foreach ($categories_data as $category) {
                      $categories_map[$category['id_category']] = $category['name'];
                  }

                  $associations_data = $socialCaseController->getAllAssociations();
                  $associations_map = [];
                  foreach ($associations_data as $association) {
                      $associations_map[$association['id_association']] = $association['name'];
                  }

                  foreach ($socialCases as $case) {
                      $statusClass = 'status-' . strtolower($case['status']);
                      $isAccepted = $case['status'] === 'Accepted';
                      $isRejected = $case['status'] === 'Rejected';
                      
                      echo '<tr>';
                      echo '<td>' . htmlspecialchars($case['id_case']) . '</td>';
                      echo '<td>' . htmlspecialchars($categories_map[$case['id_category']] ?? 'Unknown Category') . '</td>';
                      echo '<td>' . htmlspecialchars($associations_map[$case['id_association']] ?? 'Unknown Association') . '</td>';
                      echo '<td>' . htmlspecialchars($case['submited_date']) . '</td>';
                      echo '<td><span class="' . $statusClass . '">' . htmlspecialchars($case['status']) . '</span></td>';
                      echo '<td>';
                      echo '<div class="action-buttons">';
                      
                      // Accept button - always visible but disabled if already accepted
                      echo '<button type="button" class="btn btn-accept" ';
                      echo $isAccepted ? 'disabled' : 'onclick="updateStatus(' . $case['id_case'] . ', \'Accepted\')"';
                      echo '>Accept</button>';
                      
                      // Reject button - always visible but disabled if already rejected
                      echo '<button type="button" class="btn btn-reject" ';
                      echo $isRejected ? 'disabled' : 'onclick="updateStatus(' . $case['id_case'] . ', \'Rejected\')"';
                      echo '>Reject</button>';
                      
                      echo '</div>';
                      echo '</td>';
                      echo '</tr>';
                  }
                  ?>
                        </tbody>
                    </table>
                </div>
            </div>

    <script src="script.js"></script>
    <script>
    function updateStatus(caseId, newStatus) {
        if (confirm('Are you sure you want to ' + newStatus.toLowerCase() + ' this case?')) {
            // Create a form to submit the data
            const form = document.createElement('form');
            form.method = 'POST';
            form.action = 'update_status.php';
            
            // Add case ID
            const caseIdInput = document.createElement('input');
            caseIdInput.type = 'hidden';
            caseIdInput.name = 'id_case';
            caseIdInput.value = caseId;
            form.appendChild(caseIdInput);
            
            // Add new status
            const statusInput = document.createElement('input');
            statusInput.type = 'hidden';
            statusInput.name = 'status';
            statusInput.value = newStatus;
            form.appendChild(statusInput);
            
            // Add to document and submit
            document.body.appendChild(form);
            form.submit();
        }
    }
    
    // Set current date
    document.getElementById('currentDate').textContent = new Date().toLocaleDateString();
    
    function toggleNotifications() {
        alert('Notifications panel to be implemented');
    }
    
    function toggleUserMenu() {
        alert('User menu to be implemented');
    }
    </script>
</body>
</html>