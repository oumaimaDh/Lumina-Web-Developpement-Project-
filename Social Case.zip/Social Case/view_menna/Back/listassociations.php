<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lumina - Dashboard</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .dashboard-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            text-align: center;
        }
        
        .stat-number {
            font-size: 2.5em;
            font-weight: bold;
            color: #4a5568;
            margin-bottom: 10px;
        }
        
        .stat-label {
            color: #718096;
            font-size: 1.1em;
        }
        
        .recent-activities {
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .activity-item {
            padding: 15px 0;
            border-bottom: 1px solid #e2e8f0;
            display: flex;
            align-items: center;
        }
        
        .activity-item:last-child {
            border-bottom: none;
        }
        
        .activity-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: #edf2f7;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 15px;
        }
        
        .activity-content {
            flex: 1;
        }
        
        .activity-title {
            font-weight: bold;
            margin-bottom: 5px;
        }
        
        .activity-time {
            color: #718096;
            font-size: 0.9em;
        }

        /* Styles for Associations List */
        .associations-list-section {
            /* Removed styling for the section box */
        }

        .associations-list-section h2 {
            color: #333;
            margin-bottom: 20px;
            font-size: 1.8em;
            border-bottom: 2px solid #eee;
            padding-bottom: 10px;
        }

        .associations-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        .associations-table th,
        .associations-table td {
            border: 1px solid #eee;
            padding: 12px 15px;
            text-align: left;
        }

        .associations-table th {
            background-color: #f8f8f8;
            font-weight: bold;
            color: #666;
        }

        .associations-table tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        .associations-table tr:hover {
            background-color: #f1f1f1;
        }

        .btn {
    padding: 0.7rem 1.5rem;
    border-radius: 50px;
    font-weight: 500;
    cursor: pointer;
    transition: all 0.3s;
    border: none;
    display: flex;
    align-items: center;
    justify-content: center;
    width: 200px;
  
}

.btn-primary {
     background-color: #4CAF50; /* Default primary color */
    color: white;
}

.btn-outline {
    background: transparent;
    border: 2px solid var(--btn-outline-color);
    color: var(--btn-outline-color);
}

.btn i {
    margin-right: 8px;
}

.btn:hover {
    transform: translateY(-3px);
    box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
}

      

        .associations-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }

        .association-box {
            background: white;
            padding: 25px;
            border-radius: 25px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }

        .association-box h3 {
            color: #333;
            margin-bottom: 10px;
            font-size: 1.5em;
        }

        .association-box p {
            margin-bottom: 8px;
            color: #555;
        }

        .association-box .actions {
            margin-top: 15px;
            display: flex;
            gap: 10px; /* Adds space between buttons */
        }

        .association-box .actions .btn-edit,
        .association-box .actions .btn-delete {
            margin-right: 10px;
        }

        /* Styles for the filter controls container */
        .filter-controls {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
            align-items: center;
            flex-wrap: wrap;
        }

        /* Styles for search input and select dropdowns */
        .filter-controls input[type="text"],
        .filter-controls select {
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 14px;
            flex-grow: 1;
            min-width: 150px;
        }

        /* Styles for the filter button */
        .filter-controls button {
            padding: 8px 15px;
            border-radius: 4px;
            border: none;
            background-color: #007bff;
            color: white;
            cursor: pointer;
            font-size: 14px;
        }

        /* Hover effect for the filter button */
        .filter-controls button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
        <aside class="sidebar">
            <div class="sidebar-header">
                <svg class="star-icon" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z"/>
                </svg>
                <span class="logo-text">Lumina</span>
            </div>

            <nav class="sidebar-nav">
                <a href="indexb.php" class="nav-item active" data-tab="dashboard">
                    <i class="fas fa-home"></i>
                    <span>Dashboard</span>
                </a>
                <a href="social_case.php" class="nav-item" data-tab="social">
                    <i class="fas fa-heart"></i>
                    <span>Social Cases</span>
                </a>
                <a href="listassociations.php" class="nav-item active" data-tab="associations">
                    <i class="fas fa-users"></i>
                    <span>Associations</span>
                </a>
                <a href="#" class="nav-item" data-tab="jobs">
                    <i class="fas fa-briefcase"></i>
                    <span>Jobs</span>
                </a>
                <a href="#" class="nav-item" data-tab="forum">
                    <i class="fas fa-comments"></i>
                    <span>Forum</span>
                </a>
                <a href="#" class="nav-item" data-tab="settings">
                    <i class="fas fa-cog"></i>
                    <span>Settings</span>
                </a>
            </nav>

            <!-- Version Info -->
            <div class="version-info">
                <p>Version 23.0.0</p>
                <p class="version-date">2025</p>
            </div>
        </aside>

        <!-- Main Content -->
        <main class="main-content">
            <!-- Header with Logo -->
            <header class="dashboard-header">
                <!-- Logo -->
                <div class="header-logo">
                    <img src="logo.png.png" 
                         alt="Lumina Logo" 
                         class="logo-image">
                </div>

                <!-- Search Bar -->
                <div class="search-container">
                    <i class="fas fa-search search-icon"></i>
                    <input type="text" placeholder="Search jobs, associations..." class="search-input" id="globalSearch">
                </div>

                <!-- Date -->
                <div class="header-date">
                    <p id="currentDate"></p>
                </div>

                <!-- Actions -->
                <div class="header-actions">
                    <!-- Notifications -->
                    <button class="icon-btn" onclick="toggleNotifications()">
                        <i class="fas fa-bell"></i>
                        <span class="notification-dot" id="notificationDot"></span>
                    </button>

                    <!-- User Profile -->
                    <div class="user-profile" onclick="toggleUserMenu()">
                        <div class="user-info">
                            <p class="user-name">Stella Walton</p>
                            <p class="user-role">Administrator</p>
                        </div>
                        <div class="user-avatar">
                            <i class="fas fa-user"></i>
                        </div>
                    </div>
                </div>
            </header>

           
            <section class="associations-list-section">
                <?php
                // Include necessary files for database connection and controller
                require_once __DIR__ . '/../../config.php';
                require_once __DIR__ . '/../../controller_menna/socialcasecontroller.php';

                // Instantiate the controller
                $socialCaseController = new SocialCaseController();
                // Fetch all categories to populate the category filter dropdown
                $categories = $socialCaseController->getAllCategories();

                // Get search and filter parameters from the URL, if they exist
                $search = $_GET['search'] ?? '';
                $category_id = $_GET['category_id'] ?? null;
                $availabelity = $_GET['availabelity'] ?? null;

                // Fetch associations based on the applied filters
                $associations = $socialCaseController->getFilteredAssociations($search, $category_id, $availabelity);

                // Create a map for category IDs to names for display
                $categoryMap = [];
                foreach ($categories as $category) {
                    $categoryMap[$category['id_category']] = $category['name'];
                }
                ?>
                <h2>All Associations</h2>
                <!-- Filter Controls Section -->
                <div class="filter-controls">
                    <!-- Search Input Field -->
                    <input type="text" id="search-input" placeholder="Search by name, location, or email...">
                    <!-- Category Filter Dropdown -->
                    <select id="category-filter">
                        <option value="">All Categories</option>
                        <?php
                        // Populate category options dynamically from the database
                        foreach ($categories as $category) {
                            echo '<option value="' . htmlspecialchars($category['id_category']) . '">' . htmlspecialchars($category['name']) . '</option>';
                        }
                        ?>
                    </select>
                    <!-- Availability Filter Dropdown -->
                    <select id="availabelity-filter">
                        <option value="">All Availabilities</option>
                        <option value="1">Available</option>
                        <option value="0">Not Available</option>
                    </select>
                    <!-- Filter Button -->
                    <button id="filter-button" class="btn btn-primary">Filter</button>
                </div>
                <div class="associations-grid">
                    <?php

                    if (!empty($associations)) {
                        foreach ($associations as $association) {
                            echo '<div class="association-box">';
                            echo '<h3>' . htmlspecialchars($association['name']) . '</h3>';
                            echo '<p><strong>ID:</strong> ' . htmlspecialchars($association['id_association']) . '</p>';
                            echo '<p><strong>Phone:</strong> ' . htmlspecialchars($association['phone']) . '</p>';
                            echo '<p><strong>Location:</strong> ' . htmlspecialchars($association['location']) . '</p>';
                            echo '<p><strong>Email:</strong> ' . htmlspecialchars($association['email']) . '</p>';
                            echo '<p><strong>Availabelity:</strong> ' . ($association['availabelity'] ? 'Available' : 'Not Available') . '</p>';
                            $categoryName = $categoryMap[$association['id_category']] ?? 'Unknown';
                            echo '<p><strong>Category:</strong> ' . htmlspecialchars($categoryName) . '</p>';
                            echo '<div class="actions">';
                            echo '<a href="editassociation.php?id=' . htmlspecialchars($association['id_association']) . '" class="btn btn-primary">Edit</a>';
                            echo '<a href="deleteassociation.php?id=' . htmlspecialchars($association['id_association']) . '"class="btn btn-primary" onclick="return confirm(\'Are you sure you want to delete this association?\');">Delete</a>';
                            echo '</div>';
                            echo '</div>';
                        }
                    } else {
                        echo '<p>No associations found.</p>';
                    }
                    ?>
                </div>
            </section>
        </main>
    </div>

    <script>
        // Set current date
        document.getElementById('currentDate').textContent = new Date().toLocaleDateString('en-US', {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric'
        });
        
        function toggleNotifications() {
            alert('Notifications panel to be implemented');
        }
        
        function toggleUserMenu() {
            alert('User menu to be implemented');
        }

        // Update active nav item
        document.addEventListener('DOMContentLoaded', function() {
            const currentPage = window.location.pathname.split('/').pop();
            const navItems = document.querySelectorAll('.nav-item');
            
            navItems.forEach(item => {
                item.classList.remove('active');
                if (item.getAttribute('href') === currentPage) {
                    item.classList.add('active');
                }
            });

            // Set current filter values if they exist in the URL on page load
            const urlParams = new URLSearchParams(window.location.search);
            if (urlParams.has('search')) {
                document.getElementById('search-input').value = urlParams.get('search');
            }
            if (urlParams.has('category_id')) {
                document.getElementById('category-filter').value = urlParams.get('category_id');
            }
            if (urlParams.has('availabelity')) {
                document.getElementById('availabelity-filter').value = urlParams.get('availabelity');
            }
        });

        // Event listeners for filter controls
        document.getElementById('filter-button').addEventListener('click', applyFilters);
        document.getElementById('search-input').addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                applyFilters();
            }
        });
        document.getElementById('category-filter').addEventListener('change', applyFilters);
        document.getElementById('availabelity-filter').addEventListener('change', applyFilters);

        // Function to apply filters and update the URL
        function applyFilters() {
            const search = document.getElementById('search-input').value;
            const category_id = document.getElementById('category-filter').value;
            const availabelity = document.getElementById('availabelity-filter').value;

            // Construct new URL with updated search parameters
            const url = new URL(window.location.href);
            url.searchParams.set('search', search);
            url.searchParams.set('category_id', category_id);
            url.searchParams.set('availabelity', availabelity);
            // Redirect to the new URL to apply filters
            window.location.href = url.toString();
        }
    </script>
</body>
</html>