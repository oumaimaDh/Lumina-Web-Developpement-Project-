<?php
require_once __DIR__ . '/../../../config.php';
require_once __DIR__ . '/../../../controller_menna/socialcasecontroller.php';

if (isset($_GET['id'])) {
    $id_case = $_GET['id'];
    $socialCaseController = new SocialCaseController();
    $socialCaseController->deleteSocialCase($id_case);
}

header('Location: listcases.php');
exit;
?>