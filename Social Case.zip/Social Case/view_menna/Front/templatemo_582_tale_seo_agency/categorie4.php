<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">

    <title>Tale SEO Agency CSS Template by TemplateMo website</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">


    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="assets/css/fontawesome.css">
    <link rel="stylesheet" href="assets/css/templatemo-tale-seo-agency.css">
    <link rel="stylesheet" href="assets/css/owl.css">
    <link rel="stylesheet" href="assets/css/animate.css">
    <link rel="stylesheet"href="https://unpkg.com/swiper@7/swiper-bundle.min.css"/>
    <style>
      .button-container {
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100%; /* Ensure it takes full height to center vertically if needed */
      }
      .action-button {
        width: 180px; /* Fixed width for consistency */
        text-align: center;
      }
    </style>
<!--

TemplateMo 582 Tale SEO Agency

https://templatemo.com/tm-582-tale-seo-agency

-->
  <style>
    .associations-container {
      display: flex;
      flex-wrap: wrap;
      gap: 20px;
      padding: 20px;
      justify-content: center;
    }
    .association-card {
      background: white;
      padding: 20px;
      border-radius: 8px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
      width: calc(33% - 20px); /* Three cards per row with gap */
      box-sizing: border-box;
    }
    .association-card h3 {
      margin-top: 0;
      color: #333;
    }
    .association-card p {
      margin-bottom: 5px;
      color: #555;
    }
  </style>
  </head>

<body>

  <!-- ***** Preloader Start ***** -->
  <div id="js-preloader" class="js-preloader">
    <div class="preloader-inner">
      <span class="dot"></span>
      <div class="dots">
        <span></span>
        <span></span>
        <span></span>
      </div>
    </div>
  </div>
  <!-- ***** Preloader End ***** -->

  <!-- ***** Pre-Header Area Start ***** -->
 
  <!-- ***** Pre-Header Area End ***** -->

  <!-- ***** Header Area Start ***** -->
  <header class=" header-sticky">
    <nav class="navbar">
        <div class="logo">
            <img src="assets/images/logo.png" alt="Lumina Logo">
        </div>
        <ul class="nav-links">
           <li><a href="index.php"><i class="fas fa-home"></i> Home</a></li>
            <li><a href="socialcase.php"><i class="fas fa-hands-helping"></i> Social Cases</a></li>
            <li class="dropdown">
                <a href="jobdepartment.html" class="dropdown-toggle"><i class="fas fa-briefcase"></i> Job Department <i class="fas fa-chevron-down"></i></a>
                <ul class="dropdown-menu">
                    <li><a href="jobdepartment.html#job-search"><i class="fas fa-search"></i> Job Search</a></li>
                    <li><a href="jobdepartment.html#associations"><i class="fas fa-users"></i> Associations</a></li>
                    <li><a href="jobdepartment.html#application-tracking"><i class="fas fa-tasks"></i> Application Tracking</a></li>
                </ul>
            </li>
            <li><a href="events.html"><i class="fas fa-calendar-alt"></i> Our Events</a></li>
            <li><a href="forum.html"><i class="fas fa-comments"></i> Forum</a></li>
            <li class="dropdown">
                <a href="#" class="dropdown-toggle"><i class="fas fa-layer-group"></i> Pages <i class="fas fa-chevron-down"></i></a>
                <ul class="dropdown-menu">
                    <li><a href="about.html"><i class="fas fa-info-circle"></i> About Us</a></li>
                    <li><a href="faqs.html"><i class="fas fa-question-circle"></i> FAQs</a></li>
                </ul>
            </li>
        </ul>
        <div class="nav-actions">
            <button class="theme-toggle" id="theme-toggle">
                <i class="fas fa-sun"></i>
            </button>
            <button class="btn btn-outline"><i class="fas fa-sign-in-alt"></i> Login</button>
            <button class="btn btn-primary"><i class="fas fa-user-plus"></i> Sign Up</button>
        </div>
    </nav>
  </header>
  <!-- ***** Header Area End ***** -->

 



<br><br><br><br><br>
  <main class="main-content">
    <section class="associations-list-section">
      <h2>Associations in this Category</h2>
      <div class="associations-container">
        <?php
        require_once __DIR__ . '/../../../config.php';
        require_once __DIR__ . '/../../../controller_menna/socialcasecontroller.php';

        $socialCaseController = new SocialCaseController();
        $associations = $socialCaseController->getAllAssociations();
        $categories = $socialCaseController->getAllCategories();

        $categoryMap = [];
        foreach ($categories as $category) {
            $categoryMap[$category['id_category']] = $category['name'];
        }

        $filteredAssociations = array_filter($associations, function($association) {
            return $association['id_category'] == 4;
        });

        if (!empty($filteredAssociations)) {
            foreach ($filteredAssociations as $association) {
                $categoryName = $categoryMap[$association['id_category']] ?? 'Unknown';
                echo '<div class="association-card">';
                echo '<h3>' . htmlspecialchars($association['name']) . '</h3>';
                echo '<p><strong>Phone:</strong> ' . htmlspecialchars($association['phone']) . '</p>';
                echo '<p><strong>Location:</strong> ' . htmlspecialchars($association['location']) . '</p>';
                echo '<p><strong>Email:</strong> ' . htmlspecialchars($association['email']) . '</p>';
                echo '<p><strong>Availability:</strong> ' . ($association['availabelity'] ? 'Available' : 'Not Available') . '</p>';
                echo '<p><strong>Category:</strong> ' . htmlspecialchars($categoryName) . '</p>';
                echo '<button class="btn btn-primary">Send Request</button>';
                echo '</div>';
            }
        } else {
            echo '<p>No associations found in this category.</p>';
        }
        ?>
      </div>
    </section>
  </main>
 <footer>
    <div class="container">
      <div class="col-lg-12">
        <p>Copyright © 2036<a href="#">Lumina Project</a>All rights reserved
        
        <br>
Design:<a href="https://templatemo.com" target="_blank">Lumina Team</a></p>
      </div>
    </div>
  </footer>



  <!-- Scripts -->
  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

  <script src="assets/js/isotope.min.js"></script>
  <script src="assets/js/owl-carousel.js"></script>
  <script src="assets/js/tabs.js"></script>
  <script src="assets/js/popup.js"></script>
  <script src="assets/js/custom.js"></script>
  <script src="socialcase.js"></script>


  </body>

</html>
