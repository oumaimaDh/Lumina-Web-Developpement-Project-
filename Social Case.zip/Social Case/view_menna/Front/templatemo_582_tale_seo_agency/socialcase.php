<!DOCTYPE html>
<?php
require_once __DIR__ .'/../../../config.php';
require_once __DIR__ . '/../../../controller_menna/socialcasecontroller.php';
require_once __DIR__ . '/../../../Model_menna/socialcasemodel.php';

$socialCaseController = new SocialCaseController();

$categories = [];
$associations = [];

try {
    $pdo = config::getConnexion();

    // Fetch categories
    $stmt_categories = $pdo->query("SELECT id_category, name FROM category");
    $categories = $stmt_categories->fetchAll(PDO::FETCH_ASSOC);

    // Fetch associations
    $stmt_associations = $pdo->query("SELECT id_association, name FROM association");
    $associations = $stmt_associations->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    die('Database error: ' . $e->getMessage());
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $newSocialCase = new SocialCase(
        null, // id_case is auto-incremented
        $_POST['name'],
        $_POST['phone'],
        $_POST['email'],
        
        $_POST['desc'],
        $_POST['loc'],
        date('Y-m-d'), // submited_date, using current date
        date('Y-m-d'), // updated_date, using current date
        'Pending', // status, default to Pending
        (int)$_POST['catg'],
        (int)$_POST['assoc']
    );
    $socialCaseController->addSocialCase($newSocialCase);
    header('Location: listcases.php'); // Redirect to a list of cases or a success page
    exit;
}
?>

<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">

    <title>Tale SEO Agency CSS Template by TemplateMo website</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">


    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="assets/css/fontawesome.css">
    <link rel="stylesheet" href="assets/css/templatemo-tale-seo-agency.css">
    <link rel="stylesheet" href="assets/css/owl.css">
    <link rel="stylesheet" href="assets/css/animate.css">
    <link rel="stylesheet"href="https://unpkg.com/swiper@7/swiper-bundle.min.css"/>
<!--

TemplateMo 582 Tale SEO Agency

https://templatemo.com/tm-582-tale-seo-agency

-->
  </head>

<body>

  <!-- ***** Preloader Start ***** -->
  <div id="js-preloader" class="js-preloader">
    <div class="preloader-inner">
      <span class="dot"></span>
      <div class="dots">
        <span></span>
        <span></span>
        <span></span>
      </div>
    </div>
  </div>
  <!-- ***** Preloader End ***** -->

  <!-- ***** Pre-Header Area Start ***** -->
  <div class="pre-header">
    <div class="container">
      <div class="row">
        <div class="col-lg-8 col-sm-9">
          <div class="left-info">
            <ul>
              <li><a href="#"><i class="fa fa-phone"></i>+216 98 105 537</a></li>
              <li><a href="#"><i class="fa fa-envelope"></i>Lumina@email.com</a></li>
              <li><a href="#"><i class="fa fa-map-marker"></i>Tunisia Ariana El Ghazela</a></li>
            </ul>
          </div>
        </div>
        <div class="col-lg-4 col-sm-3">
          <div class="social-icons">
            <ul>
              <li><a href="#"><i class="fab fa-facebook"></i></a></li>
              <li><a href="#"><i class="fab fa-twitter"></i></a></li>
              <li><a href="#"><i class="fab fa-linkedin"></i></a></li>
              <li><a href="#"><i class="fab fa-google-plus"></i></a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- ***** Pre-Header Area End ***** -->

  <!-- ***** Header Area Start ***** -->
  <header class="header-area header-sticky">
    <nav class="navbar">
        <div class="logo">
            <img src="assets/images/logo.png" alt="Lumina Logo">
        </div>
        <ul class="nav-links">
            <li><a href="index.php"><i class="fas fa-home"></i> Home</a></li>
            <li><a href="socialcase.php"><i class="fas fa-hands-helping"></i> Social Cases</a></li>
            <li class="dropdown">
                <a href="jobdepartment.html" class="dropdown-toggle"><i class="fas fa-briefcase"></i> Job Department <i class="fas fa-chevron-down"></i></a>
                <ul class="dropdown-menu">
                    <li><a href="jobdepartment.html#job-search"><i class="fas fa-search"></i> Job Search</a></li>
                    <li><a href="jobdepartment.html#associations"><i class="fas fa-users"></i> Associations</a></li>
                    <li><a href="jobdepartment.html#application-tracking"><i class="fas fa-tasks"></i> Application Tracking</a></li>
                </ul>
            </li>
            <li><a href="events.html"><i class="fas fa-calendar-alt"></i> Our Events</a></li>
            <li><a href="forum.html"><i class="fas fa-comments"></i> Forum</a></li>
            <li class="dropdown">
                <a href="#" class="dropdown-toggle"><i class="fas fa-layer-group"></i> Pages <i class="fas fa-chevron-down"></i></a>
                <ul class="dropdown-menu">
                    <li><a href="about.html"><i class="fas fa-info-circle"></i> About Us</a></li>
                    <li><a href="faqs.html"><i class="fas fa-question-circle"></i> FAQs</a></li>
                </ul>
            </li>
        </ul>
        <div class="nav-actions">
            <button class="theme-toggle" id="theme-toggle">
                <i class="fas fa-sun"></i>
            </button>
            <button class="btn btn-outline"><i class="fas fa-sign-in-alt"></i> Login</button>
            <button class="btn btn-primary"><i class="fas fa-user-plus"></i> Sign Up</button>
        </div>
    </nav>
  </header>
  <!-- ***** Header Area End ***** -->

 




  <div class="container" style="margin-top: 200px;">
    <div class="row">
      <div class="col-lg-12">
        <div class="row">
          <div class="col-lg-3">
            <div class="item" style="background-color: white; box-shadow: 0 4px 8px rgba(0,0,0,0.1); border-radius: 15px; padding: 20px; text-align: center; aspect-ratio: 1 / 1;">
              <div class="header-text">
                <h2 style="font-weight: bold;"> Financial & Poverty Issues <br> Category 1 </h2>
                <p>Associations in this category help individuals and families facing economic hardship.
They provide food aid, financial assistance, job support, and resources to improve living conditions.</p>
                <div class="type-button">
                  <a href="categorie1.php" class="btn btn-primary">View Details</a>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-3">
            <div class="item" style="background-color: white; box-shadow: 0 4px 8px rgba(0,0,0,0.1); border-radius: 15px; padding: 20px; text-align: center; aspect-ratio: 1 / 1;">
              <div class="header-text">
                <h2 style="font-weight: bold;">Health & Medical Problems <br>Category 2</h2>
                <p>These associations support people with medical needs or disabilities.
They offer access to treatment, medicines, emergency help, and health awareness programs.</p>
                <div class="type-button" style="margin-top: 31px;">
                  <a href="categorie2.php" class="btn btn-primary">View Details</a>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-3">
            <div class="item" style="background-color: white; box-shadow: 0 4px 8px rgba(0,0,0,0.1); border-radius: 15px; padding: 20px; text-align: center; aspect-ratio: 1 / 1;">
              <div class="header-text">
                <h2 style="font-weight: bold;"> Domestic & Family Issues <br> Category 3</h2>
                <p>Organizations in this field assist with family conflicts, domestic violence, childcare, and vulnerable individuals.
They work to ensure safety, counseling, and social reintegration.</p>
                <div class="type-button" style="margin-top: 32px;">
                  <a href="categorie3.php" class="btn btn-primary">View Details</a>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-3">
            <div class="item" style="background-color: white; box-shadow: 0 4px 8px rgba(0,0,0,0.1); border-radius: 15px; padding: 20px; text-align: center; aspect-ratio: 1 / 1;">
              <div class="header-text">
                <h2 style="font-weight: bold;">Animal Welfare & Rescue<br> Category 4</h2>
                <p>Associations in this category help animals in need, especially those abandoned or injured in the streets.
They provide rescue, medical care, adoption services, and support for owners who can’t care for their animals.</p>
                <div class="type-button" style="margin-top: 3px;">
                  <a href="categorie4.php" class="btn btn-primary">View Details</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="contact-us section" id="contact">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <div class="contact-us-content">
            <div class="row">
              <div class="col-lg-4">
                <div id="map">
                  <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d12854.356468730833!2d10.165787!3d36.806496!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x12fd331b8f2c0f3b%3A0x53bbfdc9c31b6dfc!2sTunis!5e1!3m2!1sen!2stn!4v1700000000000!5m2!1sen!2stn"
width="100%" height="670px" frameborder="0" style="border:0; border-radius: 23px;" allowfullscreen=""></iframe>

                </div>
              </div>
              <div class="col-lg-8">
                <form id="contact-form" action="" method="post">
                  <div class="row">
                    <div class="col-lg-12">
                      <div class="section-heading">
                        <h2><em>Enter Your</em>  Case </h2>
                      </div>
                    </div>
                    <div >
                      <fieldset>
                        <input type="name" name="name" id="name" placeholder="Your Name..." autocomplete="on" >
                      </fieldset>
                    </div>
                    <div >
                      <fieldset>
                        <input type="phone" name="phone" id="phone" placeholder="Your phone number..." autocomplete="on" >
                      </fieldset>
                    </div>
                    <div >
                      <fieldset>
                        <input type="email" name="email" id="email" pattern="[^ @]*@[^ @]*" placeholder="Your E-mail..." >
                      </fieldset>
                    </div>
                    <div >
                      <fieldset>
                        <select name="catg" id="catg" style="border-radius: 20px; background-color:#f6e7fe; width: 650px; height: 40px;  border:0px;">
                            <option value="">Choose Your Probleme categorie</option>
                            <?php foreach ($categories as $category): ?>
                                <option value="<?php echo $category['id_category']; ?>"><?php echo htmlspecialchars($category['name']); ?></option>
                            <?php endforeach; ?>
                            
                        </select>
                      </fieldset>
                    </div>
                    <br><br>
                    <fieldset>
                        <select name="assoc" id="assoc"style="border-radius: 20px ; background-color: #f6e7fe; width: 650px; height: 40px; border:0px;">
                            <option value="">Choose an association</option>
                            <?php foreach ($associations as $association): ?>
                                <option value="<?php echo $association['id_association']; ?>"><?php echo htmlspecialchars($association['name']); ?></option>
                            <?php endforeach; ?>
                            
                        </select>
                      </fieldset>
                      <br><br>
                    <div >
                      <fieldset>
                        <textarea name="desc" id="desc" placeholder="Description"></textarea>
                      </fieldset>

                    </div>
                     <fieldset>
                        <input type="loc" name="loc" id="loc"  placeholder="Location..." >
                      </fieldset>
                    <div class="col-lg-12">
                      <div class="row">
                        <div class="col-lg-6">
                          <fieldset>
                            <button type="submit" id="form-submit" class="btn btn-primary">Submit</button>
                          </fieldset>
                        </div>
                        <div class="col-lg-6">
                          <fieldset>
                            <a href="listcases.php" class="btn btn-primary" id="view-case-button">View Your Case</a>
                          </fieldset>
                        </div>
                      </div>
                    </div>
                  </div>
                </form>
                <div class="more-info">
                  <div class="row">
                    <div class="col-lg-4">
                      <div class="info-item">
                        <i class="fa fa-phone"></i>
                        <h4><a href="#">216 98 105 537</a></h4>
                      </div>
                    </div>
                    <div class="col-lg-4">
                      <div class="info-item">
                        <i class="fa fa-envelope"></i>
                        <h4><a href="#">Lumina@gmail.com</a></h4>
                      </div>
                    </div>
                    <div class="col-lg-4">
                      <div class="info-item">
                        <i class="fa fa-map-marker"></i>
                        <h4><a href="#">Tunisia</a></h4>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>




  
 <footer>
    <div class="container">
      <div class="col-lg-12">
        <p>Copyright © 2036<a href="#">Lumina Project</a>All rights reserved
        
        <br>
Design:<a href="https://templatemo.com" target="_blank">Lumina Team</a></p>
      </div>
    </div>
  </footer>



  <!-- Scripts -->
  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

  <script src="assets/js/isotope.min.js"></script>
  <script src="assets/js/owl-carousel.js"></script>
  <script src="assets/js/tabs.js"></script>
  <script src="assets/js/popup.js"></script>
  <script src="assets/js/custom.js"></script>
  <script src="socialcase.js"></script>


  </body>

</html>
