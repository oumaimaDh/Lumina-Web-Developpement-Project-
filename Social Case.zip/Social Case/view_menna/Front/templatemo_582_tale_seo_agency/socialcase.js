document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('contact-form');
    const nameInput = document.getElementById('name');
    const phoneInput = document.getElementById('phone');
    const emailInput = document.getElementById('email');
    const catgInput = document.getElementById('catg');
    const assocInput = document.getElementById('assoc');
    const descInput = document.getElementById('desc');
    const locInput = document.getElementById('loc');

    form.addEventListener('submit', function(event) {
        let isValid = true;

        // Name validation
        if (nameInput.value.trim() === '') {
            alert('Please enter your name.');
            event.preventDefault();
            return;
        }

        // Phone validation
        if (phoneInput.value.trim() === '') {
            alert('Please enter your phone number.');
            event.preventDefault();
            return;
        }

        // Email validation
        const emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
        if (!emailPattern.test(emailInput.value.trim())) {
            alert('Please enter a valid email address.');
            event.preventDefault();
            return;
        }

        // Category validation
        if (catgInput.value === 'categorie') {
            alert('Please choose a problem category.');
            event.preventDefault();
            return;
        }

        // Association validation
        if (assocInput.value === 'categorie') {
            alert('Please choose an association.');
            event.preventDefault();
            return;
        }

        // Description validation
        if (descInput.value.trim() === '') {
            alert('Please enter a description.');
            event.preventDefault();
            return;
        }

        // Location validation
        if (locInput.value.trim() === '') {
            alert('Please enter your location.');
            event.preventDefault();
            return;
        }

        if (!isValid) {
            event.preventDefault(); // Prevent form submission if validation fails
        }
    });
});