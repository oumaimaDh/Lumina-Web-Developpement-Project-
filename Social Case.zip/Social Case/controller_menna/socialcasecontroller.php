<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../Model_menna/socialcasemodel.php';

class SocialCaseController {

    // ================= GET ALL =================
    public function getAllSocialCases() {
        $db = Config::getConnexion();
        $sql = "SELECT * FROM social_case";
        try {
            $query = $db->prepare($sql);
            $query->execute();
            return $query->fetchAll();
        } catch(Exception $e) {
            die('Erreur: '.$e->getMessage());
        }
    }

    // ================= ADD =================
    public function addSocialCase($socialCase) {
        $db = Config::getConnexion();
        $sql = "INSERT INTO social_case 
                (name, phone, email, probleme_type, description, location, 
                 submited_date, updated_date, status, id_category, id_association) 
                VALUES (:n, :p, :e, :pt, :d, :l, :idate, :udate, :s, :c, :ida)";
        try {
            $query = $db->prepare($sql);
            $query->execute([
                'n'     => $socialCase->getName(),
                'p'     => $socialCase->getPhone(),
                'e'     => $socialCase->getEmail(),
                'pt'    => $socialCase->getProblemType(),
                'd'     => $socialCase->getDescription(),
                'l'     => $socialCase->getLocation(),
                'idate' => $socialCase->getsubmitedDate(),
                'udate' => $socialCase->getUpdatedDate(),
                's'     => $socialCase->getStatus(),
                'c'     => $socialCase->getid_category(),
                'ida'   => $socialCase->getIdAssociation()
            ]);
        } catch(Exception $e) {
            die('Erreur: '.$e->getMessage());
        }
    }

    // ================= DELETE =================
    public function deleteSocialCase($id) {
        $db = Config::getConnexion();
        $sql = "DELETE FROM social_case WHERE id_case = :i";
        try {
            $query = $db->prepare($sql);
            $query->execute(['i'=>$id]);
        } catch(Exception $e) {
            die('Erreur: '.$e->getMessage());
        }
    }

    // ================= UPDATE =================
    public function updateSocialCase($socialCase) {
        $db = Config::getConnexion();
        $sql = "UPDATE social_case SET 
                    name           = :n,
                    phone          = :p,
                    email          = :e,
                    probleme_type   = :pt,
                    description    = :d,
                    location       = :l,
                    submited_date = :idate,
                    updated_date   = :udate,
                    status         = :s,
                    id_category       = :c,
                    id_association = :ida
                WHERE id_case = :i";
        try {
            $query = $db->prepare($sql);
            $query->execute([
                'n'     => $socialCase->getName(),
                'p'     => $socialCase->getPhone(),
                'e'     => $socialCase->getEmail(),
                'pt'    => $socialCase->getProblemType(),
                'd'     => $socialCase->getDescription(),
                'l'     => $socialCase->getLocation(),
                'idate' => $socialCase->getsubmitedDate(),
                'udate' => $socialCase->getUpdatedDate(),
                's'     => $socialCase->getStatus(),
                'c'     => $socialCase->getid_category(),
                'ida'   => $socialCase->getIdAssociation(),
                'i'     => $socialCase->getIdCase()
            ]);
        } catch(Exception $e) {
            die('Erreur: '.$e->getMessage());
        }
    }

    // ================= GET BY ID =================
    public function getSocialCaseById($id) {
        $db = Config::getConnexion();
        $sql = "SELECT * FROM social_case WHERE id_case = :i";
        try {
            $query = $db->prepare($sql);
            $query->execute(['i'=>$id]);
            return $query->fetch();
        } catch(Exception $e) {
            die('Erreur: '.$e->getMessage());
        }
    }
}
?>